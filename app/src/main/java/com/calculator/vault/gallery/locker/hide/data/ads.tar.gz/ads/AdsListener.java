package com.calculator.vault.gallery.locker.hide.data.ads;

public interface AdsListener {
    void onLoad();
    void onClosed();
}
